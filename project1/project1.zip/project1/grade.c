#include <stdio.h>

int main()
{
//10 Labs
int t1stLab;
int t2ndLab;
int t3rdLab;
int t4thLab;
int t5thLab;
int t6thLab;
int t7thLab;
int t8thLab;
int t9thLab;
int t10thLab;

//10 quizzes

double t1stQuiz; 
double t2ndQuiz;
double t3rdQuiz;
double t4thQuiz;
double t5thQuiz;
double t6thQuiz;
double t7thQuiz;
double t8thQuiz;
double t9thQuiz;
double t10thQuiz;

//10 textbook exercise

double t1stText; 
double t2ndText;
double t3rdText;
double t4thText;
double t5thText;
double t6thText;
double t7thText; 
double t8thText;
double t9thText;
double t10thText;

//6 projecrs


int t1stPro;
int t2ndPro;
int t3rdPro;
int t4thPro;
int t5thPro;
int t6thPro;

//4 exams


double t1stExam;
double t2ndExam;
double t3rdExam;
double t4thExam;

double labpercent;
double quizpercent;
double textpercent;
double projectpercent;
double exampercent;

double avg;
//input Lab score

	printf("Enter your 1st Lab Score:(Interger)\n");
	
	scanf("%d",&t1stLab);
	printf("Enter your 2nd Lab Score:(Interger)\n");
	
	scanf("%d",&t2ndLab);	
	printf("Enter your 3rd Lab Score:(Interger)\n");

	scanf("%d",&t3rdLab);

	printf("Enter your 4th Lab Score:(Interger)\n");

	scanf("%d",&t4thLab);
	printf("Enter your 5th Lab Score:(Interger)\n");

	scanf("%d",&t5thLab);
	printf("Enter your 6th Lab Score:(Interger)\n");

	scanf("%d",&t6thLab);
	printf("Enter your 7th Lab Score:(Interger)\n");

	scanf("%d",&t7thLab);
	printf("Enter your 8th Lab Score:(Interger)\n");

	scanf("%d",&t8thLab);
	printf("Enter your 9th Lab Score:(Interger)\n");

	scanf("%d",&t9thLab);
	printf("Enter your 10th Lab Score:(Interger)\n");

	scanf("%d",&t10thLab);
//input quizzes Scores



	printf("Enter your 1st Quiz Score:(Real Number)\n");

	scanf("%lf",&t1stQuiz);
	printf("Enter your 2nd Quiz Score:(Real Number)\n");

	scanf("%lf",&t2ndQuiz);
	printf("Enter your 3rd Quiz Score:(Real Number)\n");

	scanf("%lf",&t3rdQuiz);
	printf("Enter your 4th Quiz Score:(Real Number)\n");

	scanf("%lf",&t4thQuiz);
	printf("Enter your 5th Quiz Score:(Real Number)\n");

	scanf("%lf",&t5thQuiz);
	printf("Enter your 6th Quiz Score:(Real Number)\n");

	scanf("%lf",&t6thQuiz);
	printf("Enter your 7th Quiz Score:(Real Number)\n");

	scanf("%lf",&t7thQuiz);
	printf("Enter your 8th Quiz Score:(Real Number)\n");

	scanf("%lf",&t8thQuiz);
	printf("Enter your 9th Quiz Score:(Real Number)\n");

	scanf("%lf",&t9thQuiz);
	printf("Enter your 10th Quiz Score:(Real Nunmer)\n");

	scanf("%lf",&t10thQuiz);

//input text exercise


	printf("Enter your 1st Text Score:(Real Number)\n");

	scanf("%lf",&t1stText);
	printf("Enter your 2nd Text Score:(Real Number)\n");

	scanf("%lf",&t2ndText);
	printf("Enter your 3rd Text Score:(Real Number)\n");

	scanf("%lf",&t3rdText);
	printf("Enter your 4th Text Score:(Real Number)\n");

	scanf("%lf",&t4thText);
	printf("Enter your 5th Text Score:(Real Number)\n");

	scanf("%lf",&t5thText);
	printf("Enter your 6th Text Score:(Real Number)\n");

	scanf("%lf",&t6thText);
	printf("Enter your 7th Text Score:(Real Number)\n");

	scanf("%lf",&t7thText);
	printf("Enter your 8th Text Score:(Real Number)\n");

	scanf("%lf",&t8thText);
	printf("Enter your 9th Text Score:(Real Number)\n");

	scanf("%lf",&t9thText);
	printf("Enter your 10th Text Score:(Real Number)\n");

	scanf("%lf",&t10thText);

//input project score

	printf("Enter your 1st Project Score:(Interger)\n");

	scanf("%d",&t1stPro);
	printf("Enter your 2nd Project Score:(Interger)\n");

	scanf("%d",&t2ndPro);
	printf("Enter your 3rd Projrct Score:(Interger)\n");

	scanf("%d",&t3rdPro);
	printf("Enter your 4th Project Score:(Interger)\n");

	scanf("%d",&t4thPro);
	printf("Enter your 5th Project Score:(Interger)\n");

	scanf("%d",&t5thPro);
	printf("Enter your 6th Project Score:(Interger)\n");

	scanf("%d",&t6thPro);
//input exam Scores

	printf("Enter your 1st Exam Score:(Real Number)\n");

	scanf("%lf",&t1stExam);
	printf("Enter your 2nd Exam Score:(Real Number)\n");

	scanf("%lf",&t2ndExam);
	printf("Enter your 3rd Exam Score:(Real Number)\n");

	scanf("%lf",&t3rdExam);
	printf("Enter your Final Exam Score:(Real Number)\n");

	scanf("%lf",&t4thExam);

//calculate

labpercent = 0.01 * ( t1stLab + t2ndLab + t3rdLab + t4thLab + t5thLab + t6thLab + t7thLab + t8thLab + t9thLab + t10thLab);
 
quizpercent = 0.1 * (t1stQuiz + t2ndQuiz + t3rdQuiz + t4thQuiz + t5thQuiz + t6thQuiz + t7thQuiz + t8thQuiz + t9thQuiz + t10thQuiz);

textpercent = 0.01 * (t1stText + t2ndText + t3rdText + t4thText + t5thText + t6thText + t7thText + t8thText + t9thText + t10thText);

projectpercent = 0.02 * t1stPro + 0.04 * (t2ndPro + t3rdPro) + 0.05 * (t4thPro + t5thPro + t6thPro);

exampercent = 0.1 * (t1stExam + t2ndExam + t3rdExam) + 0.15 * t4thExam;

avg = labpercent + quizpercent + textpercent + projectpercent+ exampercent;

printf("Your semester weighted average is %lf.\n",avg);




	return 0;
}
